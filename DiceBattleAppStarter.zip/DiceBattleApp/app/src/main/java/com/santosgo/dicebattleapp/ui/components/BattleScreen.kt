package com.santosgo.dicebattleapp.ui.components

import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.santosgo.dicebattleapp.R

@Composable
fun BattleScreen(modifier: Modifier = Modifier, onClickEndGame: (String, Int) -> Unit) {
    var player1 by rememberSaveable { mutableStateOf("") }
    var num1 by rememberSaveable { mutableIntStateOf(0) }
    var total1 by rememberSaveable { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            Modifier
                .weight(2f),
            verticalAlignment = Alignment.CenterVertically,
            ) {
            StandardInputTextComp(
                label = stringResource(R.string.player_1),
                value = player1,
                onValueChange = { player1 = it }
            )
        }
        Row(
            Modifier
                .weight(4f),
            verticalAlignment = Alignment.CenterVertically) {
            DiceComp(num = num1)
        }
        Row (
            Modifier
                .weight(2f),
            verticalAlignment = Alignment.CenterVertically
            ) {
            StandardButtonComp(
                label = stringResource(R.string.throw_dice),
                enabled = player1.isNotBlank(),
                onClick = {
                    num1 = (1..6).random()
                    total1 += num1
                }
            )
        }
        Row (
            Modifier
                .weight(2f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if(num1 != 0) {
                Column {
                    LabelAndValueComp(label = stringResource(R.string.result), value = num1.toString())
                    LabelAndValueComp(label = stringResource(R.string.total), value = total1.toString())
                    StandardButtonComp(
                        label = stringResource(R.string.finish),
                        onClick = { onClickEndGame(player1, total1) }
                    )
                }
            }
        }
    }
}

